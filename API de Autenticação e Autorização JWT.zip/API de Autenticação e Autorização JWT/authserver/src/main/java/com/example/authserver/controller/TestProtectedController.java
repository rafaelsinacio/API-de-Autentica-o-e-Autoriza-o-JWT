package com.example.authserver.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Tag(name = "Recursos Protegidos", description = "Endpoints que exigem autenticação JWT")
@SecurityRequirement(name = "bearerAuth")
public class TestProtectedController {

    @Operation(summary = "Acessível por qualquer usuário autenticado")
    @GetMapping("/hello")
    public ResponseEntity<String> hello() {
        return ResponseEntity.ok("Olá! Você acessou um endpoint protegido com sucesso!");
    }

    @Operation(summary = "Acessível apenas por usuários com role 'ADMIN'")
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin")
    public ResponseEntity<String> adminOnly() {
        return ResponseEntity.ok("Bem-vindo, Administrador! Este é um recurso restrito.");
    }
}
