package com.example.authserver;

import com.example.authserver.model.User;
import com.example.authserver.repository.UserRepository;
import com.example.authserver.service.AuthService;
import com.example.authserver.service.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AuthIntegrationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final String ADMIN_USERNAME = "admin";
    private final String ADMIN_PASSWORD = "123456";

    private final String USER_USERNAME = "user";
    private final String USER_PASSWORD = "password";

    @BeforeEach
    void setupUsers() {
        createUserIfNotExists(ADMIN_USERNAME, ADMIN_PASSWORD, "ADMIN");
        createUserIfNotExists(USER_USERNAME, USER_PASSWORD, "USER");
    }

    private void createUserIfNotExists(String username, String rawPassword, String role) {
        userRepository.findByUsername(username).orElseGet(() -> {
            User newUser = new User(null, username, passwordEncoder.encode(rawPassword), role);
            return userRepository.save(newUser);
        });
    }

    @Nested
    @DisplayName("Login Tests")
    class LoginTests {

        @Test
        @DisplayName("Deve retornar token JWT válido ao logar com credenciais corretas")
        void testLoginSuccess() throws Exception {
            String token = mockMvc.perform(post("/auth/login")
                            .param("username", ADMIN_USERNAME)
                            .param("password", ADMIN_PASSWORD)
                            .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                    .andExpect(status().isOk())
                    .andReturn()
                    .getResponse()
                    .getContentAsString();

            assertTrue(jwtService.validateToken(token), "O token JWT retornado não é válido.");
        }

        @Test
        @DisplayName("Deve retornar 401 ao tentar logar com senha incorreta")
        void testLoginFailureInvalidPassword() throws Exception {
            mockMvc.perform(post("/auth/login")
                            .param("username", ADMIN_USERNAME)
                            .param("password", "senhaErrada")
                            .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                    .andExpect(status().isUnauthorized())
                    .andExpect(content().string(containsString("Senha incorreta.")));
        }
    }

    @Nested
    @DisplayName("Endpoints Protegidos")
    class ProtectedEndpointsTests {

        @Test
        @DisplayName("Deve negar acesso sem token no header")
        void testAccessDeniedWithoutToken() throws Exception {
            mockMvc.perform(get("/api/hello"))
                    .andExpect(status().isUnauthorized());
        }

        @Test
        @DisplayName("Deve permitir acesso com token válido")
        void testAccessWithValidToken() throws Exception {
            String token = performLogin(USER_USERNAME, USER_PASSWORD);

            mockMvc.perform(get("/api/hello")
                            .header("Authorization", "Bearer " + token))
                    .andExpect(status().isOk())
                    .andExpect(content().string("Olá! Você acessou um endpoint protegido com sucesso!"));
        }

        @Test
        @DisplayName("Administrador deve acessar endpoint admin com sucesso")
        void testAdminAccessToAdminEndpoint() throws Exception {
            String adminToken = performLogin(ADMIN_USERNAME, ADMIN_PASSWORD);

            mockMvc.perform(get("/api/admin")
                            .header("Authorization", "Bearer " + adminToken))
                    .andExpect(status().isOk())
                    .andExpect(content().string("Bem-vindo, Administrador! Este é um recurso restrito."));
        }

        @Test
        @DisplayName("Usuário comum não deve acessar endpoint admin")
        void testUserDeniedAccessToAdminEndpoint() throws Exception {
            String userToken = performLogin(USER_USERNAME, USER_PASSWORD);

            mockMvc.perform(get("/api/admin")
                            .header("Authorization", "Bearer " + userToken))
                    .andExpect(status().isForbidden());
        }

        private String performLogin(String username, String password) throws Exception {
            return mockMvc.perform(post("/auth/login")
                            .param("username", username)
                            .param("password", password)
                            .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                    .andExpect(status().isOk())
                    .andReturn()
                    .getResponse()
                    .getContentAsString();
        }
    }
}
